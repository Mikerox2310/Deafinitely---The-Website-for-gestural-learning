let bg;
let img;
let img1;
let img2;
let img3;
let img4;
let img5;
let img6;
let img7;

// Classifier Variable
let classifier;
// Model URL
let imageModelURL = 'https://teachablemachine.withgoogle.com/models/U07tIKmK-/';

// Video
let video;
let flippedVideo;
// To store the classification
let label = "";

// Load the model first
function preload() {
  classifier = ml5.imageClassifier(imageModelURL + 'model.json');
}

function setup() {
  bg = loadImage('BG.png');
  img = loadImage('1.JPG')
  img1= loadImage('A.JPG')
  img2= loadImage('B.JPG')
  img3=loadImage('C.JPG')
  img4 = loadImage('V.JPG')
  img5 = loadImage('W.JPG')
  img6 = loadImage('4.jpg')
  
img7 = loadImage('5.JPG')
  
  createCanvas(1920, 1080);
  // Create the video
  video = createCapture(VIDEO);
  video.size(640, 480);
  video.hide();

  flippedVideo = ml5.flipImage(video)
  // Start classifying
  classifyVideo();
}

function draw() {
  background(bg);
  
  image(img,60,275,477,656)
  
  image(img1,1400,300)
  
  image(img2,1600,300)
  
  image(img3,1400,500)
  
  image(img4,1600,500)
  
  image(img5,1400,715)
  
  image(img6,1600,750,150,170)
  
   image(img7,1725,515,180,165)
  
  // Draw the video
  image(flippedVideo, 630, 330);

  // Draw the label
  fill(0);
  textSize(50)
  textAlign(CENTER);
  text(label, width / 2, 920);
}

// Get a prediction for the current video frame
function classifyVideo() {
  flippedVideo = ml5.flipImage(video)
  classifier.classify(flippedVideo, gotResult);
}

// When we get a result
function gotResult(error, results) {
  // If there is an error
  if (error) {
    console.error(error);
    return;
  }
  // The results are in an array ordered by confidence.
  // console.log(results[0]);
  label = results[0].label;
  // Classifiy again!
  classifyVideo();
}